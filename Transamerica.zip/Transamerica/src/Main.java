public class Main {

	static Player[] players = new Player[6];

	// public static void main(String[] args) {
	// Game game = new Game(players);
	// }
}